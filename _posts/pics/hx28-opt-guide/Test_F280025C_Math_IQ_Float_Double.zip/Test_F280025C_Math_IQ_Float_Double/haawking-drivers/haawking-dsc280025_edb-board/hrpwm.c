//###########################################################################
//
// FILE:   hrpwm.c
//
// TITLE:  H28x HRPWM driver.
//
//###########################################################################
// $HAAWKING Release: Hal Driver Support Library V1.0.5 $
// $Release Date: 2023-04-28 06:49:27 $
// $Copyright:
// Copyright (C) 2019-2023 Beijing Haawking Technology Co.,Ltd - http://www.haawking.com/
//###########################################################################

#include "hrpwm.h"

//
// All the API functions are in-lined in hrpwm.h
//
